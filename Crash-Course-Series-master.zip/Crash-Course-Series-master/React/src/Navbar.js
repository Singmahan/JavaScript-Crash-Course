import React from 'react';

function Navbar() {
  return <header className="Navbar">Facebook</header>;
}

export default Navbar;
